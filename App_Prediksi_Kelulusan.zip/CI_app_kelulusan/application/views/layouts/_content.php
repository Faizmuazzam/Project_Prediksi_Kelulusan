<div class="wrapper">
    
    <?= @$navbar; ?>
    <?= @$sidebar; ?>
    
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <?= @$main; ?>
    </div>
    <!-- /.content-wrapper -->


    <?= @$footer; ?>
</div>