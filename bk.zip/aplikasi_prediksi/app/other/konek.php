<?php
$host ="127.0.0.1";
$user ="root";
$pass ="";
$debe ="prediksi_kelulusan";//nama database

$db = new mysqli($host,$user,$pass,$debe)or die($db->error);
?>